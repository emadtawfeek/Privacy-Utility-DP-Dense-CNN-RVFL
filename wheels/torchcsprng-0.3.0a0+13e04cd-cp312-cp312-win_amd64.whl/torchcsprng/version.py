__version__ = '0.3.0a0+13e04cd'
git_version = '13e04cdd038a049ae47c6c25e9a8f34ea546193f'
